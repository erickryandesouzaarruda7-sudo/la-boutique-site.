import React, { useState, useEffect, useMemo } from 'react';
import {
  ShoppingBag,
  Heart,
  Search,
  User,
  X,
  Menu,
  ChevronRight,
  SlidersHorizontal,
  ArrowRight,
  Phone,
  Mail,
  MapPin,
  Clock,
  ShieldCheck,
  Truck,
  RefreshCw,
  MessageCircle,
  Plus,
  Minus,
  Trash2,
  Lock,
  Edit,
  Save,
  Check,
  Star,
  Instagram,
  Facebook,
  ExternalLink,
  Sparkles,
  Info,
  HelpCircle
} from 'lucide-react';

// --- INITIAL DEMO DATA & STORE CONFIGURATION ---
const INITIAL_STORE_CONFIG = {
  announcementText: "Atendimento exclusivo via WhatsApp | Ateliê nos Jardins, São Paulo",
  whatsappNumber: "5511999998888",
  whatsappFormatted: "(11) 99999-8888",
  isDemoNoticeVisible: true
};

const INITIAL_PRODUCTS = [
  {
    id: "lb-001",
    name: "Blazer Alfaiataria Duplo Abotoamento",
    category: "Alfaiataria",
    price: 890.00,
    oldPrice: 1050.00,
    images: [
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=1000&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1548883354-7622d03aca27?q=80&w=1000&auto=format&fit=crop"
    ],
    sizes: ["PP", "P", "M", "G"],
    colors: [
      { name: "Preto", hex: "#1A1A1A" },
      { name: "Nude", hex: "#E8DFD8" },
      { name: "Off-White", hex: "#F4F1EA" }
    ],
    isNew: true,
    isFeatured: true,
    stock: 8,
    description: "Blazer confeccionado em tecido estruturado de alfaiataria com toque macio. Possui lapela xale, abotoamento duplo frontal com botões forrados e forro acetinado. Modelagem impecável para composições elegantes e atemporais.",
    composition: "96% Poliéster, 4% Elastano. Forro: 100% Acetato.",
    care: "Lavar a seco em lavanderia especializada."
  },
  {
    id: "lb-002",
    name: "Vestido Midi Plissado em Seda Sintética",
    category: "Vestidos",
    price: 1290.00,
    images: [
      "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?q=80&w=1000&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1000&auto=format&fit=crop"
    ],
    sizes: ["P", "M", "G"],
    colors: [
      { name: "Nude Gold", hex: "#D4AF37" },
      { name: "Preto Ébano", hex: "#1A1A1A" }
    ],
    isNew: true,
    isFeatured: true,
    stock: 5,
    description: "Vestido midi com saia fluida plissada e decote V delicado. Cintura marcada por faixa sutil do próprio tecido. Perfeito para eventos sociais sofisticados e jantares formais.",
    composition: "100% Poliéster de Alta Densidade com Efeito Acetinado.",
    care: "Lavar à mão com sabão neutro. Secar à sombra."
  },
  {
    id: "lb-003",
    name: "Tricô Gola Alta em Fio Cashmere Touch",
    category: "Tricô",
    price: 640.00,
    images: [
      "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?q=80&w=1000&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=1000&auto=format&fit=crop"
    ],
    sizes: ["PP", "P", "M", "G", "GG"],
    colors: [
      { name: "Bege Areia", hex: "#E8DFD8" },
      { name: "Off-White", hex: "#F4F1EA" }
    ],
    isNew: false,
    isFeatured: true,
    stock: 12,
    description: "Suéter de tricot encorpado com toque aconchegante estilo cashmere. Gola alta estruturada e punhos com acabamento em canelado fino. Essencial para os dias mais frios com elegância extrema.",
    composition: "50% Viscose, 30% Poliamida, 20% Poliéster.",
    care: "Lavar à mão, não torcer. Guardar dobrado."
  },
  {
    id: "lb-004",
    name: "Calça Wide Leg Alfaiataria Premium",
    category: "Alfaiataria",
    price: 720.00,
    images: [
      "https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=1000&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1584370848010-d7fe6bc767ec?q=80&w=1000&auto=format&fit=crop"
    ],
    sizes: ["36", "38", "40", "42"],
    colors: [
      { name: "Preto", hex: "#1A1A1A" },
      { name: "Bege Fendi", hex: "#C5B2A1" }
    ],
    isNew: false,
    isFeatured: true,
    stock: 7,
    description: "Calça feminina modelo wide leg em alfaiataria encorpada com vinco frontal que me alonga a silhueta. Cintura alta com cós estruturado e fechamento por gancho embutido.",
    composition: "95% Poliéster, 5% Elastano.",
    care: "Lavar à máquina em ciclo delicado."
  },
  {
    id: "lb-005",
    name: "Camisa de Seda Pura com Botões Perolados",
    category: "Camisas",
    price: 980.00,
    images: [
      "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=1000&auto=format&fit=crop"
    ],
    sizes: ["PP", "P", "M", "G"],
    colors: [
      { name: "Off-White", hex: "#F4F1EA" },
      { name: "Nude Suave", hex: "#E8DFD8" }
    ],
    isNew: true,
    isFeatured: false,
    stock: 4,
    description: "Camisa clássica confeccionada em toque de seda pura. Caimento fluido, punhos alongados e abotoamento frontal com botões com acabamento madrepérola.",
    composition: "100% Seda Natural.",
    care: "Lavar a seco em lavanderia especializada."
  },
  {
    id: "lb-006",
    name: "Sobretudo Longo Wool Blend Jardins",
    category: "Casacos",
    price: 1890.00,
    images: [
      "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?q=80&w=1000&auto=format&fit=crop"
    ],
    sizes: ["P", "M", "G"],
    colors: [
      { name: "Camel Elegance", hex: "#B8860B" },
      { name: "Preto Noite", hex: "#1A1A1A" }
    ],
    isNew: true,
    isFeatured: false,
    stock: 3,
    description: "Casaco sobretudo longo confeccionado em mistura nobre de lã. Corte estruturado, gola imponente e cinto faixa removível para amarração na cintura.",
    composition: "70% Lã, 30% Poliamida. Forro: 100% Viscose.",
    care: "Lavar a seco."
  }
];

export default function App() {
  // Navigation & View state
  const [currentView, setCurrentView] = useState('home'); // 'home', 'catalog', 'about', 'contact', 'faq', 'admin'
  const [selectedProduct, setSelectedProduct] = useState(null);
  
  // Data State
  const [products, setProducts] = useState(INITIAL_PRODUCTS);
  const [storeConfig, setStoreConfig] = useState(INITIAL_STORE_CONFIG);
  
  // Store Drawers & Modals
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Interactive Filters for Catalog
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [selectedSizeFilter, setSelectedSizeFilter] = useState('Todos');
  const [sortBy, setSortBy] = useState('newest'); // 'newest', 'price-asc', 'price-desc', 'popular'
  const [priceRange, setPriceRange] = useState(2500);

  // User Commerce State
  const [cart, setCart] = useState([]);
  const [wishlist, setWishlist] = useState([]);

  // Admin Auth & State
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminPinInput, setAdminPinInput] = useState('');
  const [adminError, setAdminError] = useState('');
  const [editingProduct, setEditingProduct] = useState(null);

  // Form states
  const [checkoutStep, setCheckoutStep] = useState('cart'); // 'cart', 'address', 'confirmation'
  const [customerData, setCustomerData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: 'São Paulo',
    state: 'SP',
    zipCode: '',
    notes: ''
  });
  
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterConsented, setNewsletterConsented] = useState(false);
  const [newsletterSuccess, setNewsletterSuccess] = useState(false);

  // Format Currencies
  const formatBRL = (val) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
  };

  // Cart Logic
  const addToCart = (product, size, color) => {
    const cartItemId = `${product.id}-${size}-${color.name}`;
    setCart(prevCart => {
      const existing = prevCart.find(item => item.cartItemId === cartItemId);
      if (existing) {
        return prevCart.map(item =>
          item.cartItemId === cartItemId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevCart, {
        cartItemId,
        product,
        size,
        color,
        quantity: 1,
        unitPrice: product.price
      }];
    });
    setIsCartOpen(true);
  };

  const updateCartQty = (cartItemId, delta) => {
    setCart(prev => prev.map(item => {
      if (item.cartItemId === cartItemId) {
        const newQty = item.quantity + delta;
        return newQty > 0 ? { ...item, quantity: newQty } : null;
      }
      return item;
    }).filter(Boolean));
  };

  const removeFromCart = (cartItemId) => {
    setCart(prev => prev.filter(item => item.cartItemId !== cartItemId));
  };

  const cartSubtotal = useMemo(() => {
    return cart.reduce((acc, item) => acc + (item.unitPrice * item.quantity), 0);
  }, [cart]);

  // Wishlist Logic
  const toggleWishlist = (product) => {
    setWishlist(prev => {
      const exists = prev.some(item => item.id === product.id);
      if (exists) return prev.filter(item => item.id !== product.id);
      return [...prev, product];
    });
  };

  // WhatsApp Link Generator for Single Product
  const generateWhatsAppProductLink = (product, size, color) => {
    const text = `Olá, La Boutique! Tenho interesse no produto [DEMO]:\n\n` +
      `• *Produto:* ${product.name}\n` +
      `• *Tamanho:* ${size || 'Não informado'}\n` +
      `• *Cor:* ${color?.name || 'Não informada'}\n` +
      `• *Valor:* ${formatBRL(product.price)}\n\n` +
      `Gostaria de verificar a disponibilidade de atendimento na loja de São Paulo.`;
    return `https://wa.me/${storeConfig.whatsappNumber}?text=${encodeURIComponent(text)}`;
  };

  // WhatsApp Link Generator for Entire Cart
  const generateWhatsAppCartLink = () => {
    let text = `*NOVO PEDIDO DE DEMONSTRAÇÃO - LA BOUTIQUE SP*\n\n`;
    text += `*Cliente:* ${customerData.name || 'Cliente'}\n`;
    text += `*Telefone:* ${customerData.phone || 'Não informado'}\n`;
    text += `*Endereço:* ${customerData.address}, ${customerData.city} - ${customerData.state}\n\n`;
    text += `*ITENS SOLICITADOS:*\n`;

    cart.forEach((item, idx) => {
      text += `${idx + 1}. ${item.product.name}\n`;
      text += `   - Tam: ${item.size} | Cor: ${item.color.name}\n`;
      text += `   - Qtd: ${item.quantity} x ${formatBRL(item.unitPrice)} = ${formatBRL(item.unitPrice * item.quantity)}\n\n`;
    });

    text += `*SUBTOTAL:* ${formatBRL(cartSubtotal)}\n`;
    text += `\n_Aguardando confirmação de disponibilidade e atendimento exclusivo._`;

    return `https://wa.me/${storeConfig.whatsappNumber}?text=${encodeURIComponent(text)}`;
  };

  // Filter & Sort Products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchesCategory = selectedCategory === 'Todos' || p.category === selectedCategory;
      const matchesSize = selectedSizeFilter === 'Todos' || p.sizes.includes(selectedSizeFilter);
      const matchesPrice = p.price <= priceRange;
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            p.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSize && matchesPrice && matchesSearch;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'popular') return b.stock - a.stock;
      return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
    });
  }, [products, selectedCategory, selectedSizeFilter, priceRange, searchQuery, sortBy]);

  // Handle Admin Login
  const handleAdminAuth = (e) => {
    e.preventDefault();
    if (adminPinInput === '1234' || adminPinInput === 'admin') {
      setIsAdminAuthenticated(true);
      setAdminError('');
    } else {
      setAdminError('PIN incorreto. Utilize "1234" para acesso demonstrativo.');
    }
  };

  // Newsletter Submit
  const handleNewsletterSubmit = (e) => {
    e.preventDefault();
    if (!newsletterConsented) return;
    setNewsletterSuccess(true);
    setTimeout(() => {
      setNewsletterSuccess(false);
      setNewsletterEmail('');
    }, 4000);
  };

  // Auto Scroll to Top on View Change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentView, selectedProduct]);

  return (
    <div className="min-h-screen bg-[#FBF9F5] text-[#1A1A1A] font-sans selection:bg-[#E8DFD8] selection:text-[#1A1A1A]">
      
      {/* 0. DEMO NOTICE BAR */}
      {storeConfig.isDemoNoticeVisible && (
        <div className="bg-[#1A1A1A] text-[#E8DFD8] text-xs py-1.5 px-4 text-center border-b border-[#C5A059]/30 flex items-center justify-between">
          <div className="flex-1 flex items-center justify-center gap-2">
            <Info className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>
              <strong>Modo de Demonstração Comercial:</strong> Produtos fictícios. Não realiza cobranças reais. 
              Número WhatsApp atual: <span className="underline font-mono">{storeConfig.whatsappFormatted}</span>
            </span>
          </div>
          <button 
            onClick={() => setStoreConfig(prev => ({ ...prev, isDemoNoticeVisible: false }))}
            className="text-gray-400 hover:text-white text-xs ml-2"
            title="Fechar aviso"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 1. TOP ANNOUNCEMENT BAR */}
      <div className="bg-[#E8DFD8]/60 text-[#1A1A1A] text-xs py-2 px-4 text-center uppercase tracking-widest font-light border-b border-[#E8DFD8]">
        {storeConfig.announcementText}
      </div>

      {/* 2. MAIN HEADER & NAVIGATION */}
      <header className="sticky top-0 z-40 bg-[#FBF9F5]/90 backdrop-blur-md border-b border-[#E8DFD8]/50 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            
            {/* Mobile menu trigger */}
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#1A1A1A] hover:text-[#C5A059] transition-colors"
              aria-label="Abrir menu"
            >
              <Menu className="w-6 h-6" />
            </button>

            {/* Brand Logo */}
            <div className="flex-1 lg:flex-none text-center lg:text-left cursor-pointer" onClick={() => setCurrentView('home')}>
              <h1 className="font-serif text-2xl sm:text-3xl tracking-widest uppercase text-[#1A1A1A]">
                La Boutique
              </h1>
              <p className="text-[9px] tracking-[0.3em] uppercase text-[#C5A059] font-medium -mt-1">
                São Paulo
              </p>
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-8 text-xs font-medium tracking-widest uppercase">
              {[
                { id: 'home', label: 'Início' },
                { id: 'catalog', label: 'Coleção' },
                { id: 'about', label: 'Sobre Nós' },
                { id: 'contact', label: 'Contato' },
                { id: 'faq', label: 'Políticas & FAQ' }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentView(item.id);
                    if (item.id === 'catalog') {
                      setSelectedCategory('Todos');
                    }
                  }}
                  className={`relative py-1 transition-colors hover:text-[#C5A059] ${
                    currentView === item.id ? 'text-[#C5A059] font-semibold' : 'text-[#1A1A1A]/80'
                  }`}
                >
                  {item.label}
                  {currentView === item.id && (
                    <span className="absolute bottom-0 left-0 w-full h-[1px] bg-[#C5A059]" />
                  )}
                </button>
              ))}
            </nav>

            {/* Right Action Icons */}
            <div className="flex items-center space-x-4 sm:space-x-5">
              <button 
                onClick={() => setIsSearchOpen(true)}
                className="p-2 text-[#1A1A1A] hover:text-[#C5A059] transition-colors"
                title="Buscar produtos"
              >
                <Search className="w-5 h-5" />
              </button>

              <button 
                onClick={() => setIsWishlistOpen(true)}
                className="p-2 text-[#1A1A1A] hover:text-[#C5A059] transition-colors relative"
                title="Favoritos"
              >
                <Heart className="w-5 h-5" />
                {wishlist.length > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-[#C5A059] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    {wishlist.length}
                  </span>
                )}
              </button>

              <button 
                onClick={() => setIsCartOpen(true)}
                className="p-2 text-[#1A1A1A] hover:text-[#C5A059] transition-colors relative"
                title="Sacola de Compras"
              >
                <ShoppingBag className="w-5 h-5" />
                {cart.length > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-[#1A1A1A] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    {cart.reduce((a, c) => a + c.quantity, 0)}
                  </span>
                )}
              </button>

              <button 
                onClick={() => setCurrentView('admin')}
                className={`p-2 transition-colors rounded-full ${
                  currentView === 'admin' ? 'bg-[#1A1A1A] text-[#C5A059]' : 'text-[#1A1A1A] hover:text-[#C5A059]'
                }`}
                title="Painel Administrativo Demo"
              >
                <User className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#FBF9F5] border-b border-[#E8DFD8] px-6 py-6 space-y-4">
            {[
              { id: 'home', label: 'Início' },
              { id: 'catalog', label: 'Coleção Completa' },
              { id: 'about', label: 'Sobre A Marca' },
              { id: 'contact', label: 'Contato & Ateliê' },
              { id: 'faq', label: 'Perguntas & Políticas' },
              { id: 'admin', label: 'Painel da Loja (Demo)' }
            ].map(item => (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentView(item.id);
                  setMobileMenuOpen(false);
                }}
                className="block w-full text-left text-sm uppercase tracking-widest py-2 border-b border-[#E8DFD8]/40 text-[#1A1A1A]"
              >
                {item.label}
              </button>
            ))}
          </div>
        )}
      </header>

      {/* 3. DYNAMIC MAIN BODY CONTENT BASED ON CURRENT VIEW */}
      <main>
        
        {/* ==================== VIEW: HOME ==================== */}
        {currentView === 'home' && (
          <div>
            {/* HERO SECTION */}
            <section className="relative h-[85vh] min-h-[550px] flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 z-0">
                <img 
                  src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=2000&auto=format&fit=crop" 
                  alt="La Boutique High Fashion Editorial" 
                  className="w-full h-full object-cover object-center filter brightness-[0.82]"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-black/30" />
              </div>

              <div className="relative z-10 text-center text-white px-4 max-w-3xl mx-auto space-y-6">
                <span className="text-xs uppercase tracking-[0.4em] text-[#E8DFD8] font-light">
                  Coleção Outono / Inverno São Paulo
                </span>
                <h2 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-normal leading-tight tracking-tight">
                  Elegância em cada detalhe.
                </h2>
                <p className="text-sm sm:text-base font-light text-[#F4F1EA]/90 max-w-xl mx-auto tracking-wide">
                  Descubra peças exclusivas de alta alfaiataria que combinam sofisticação com o seu estilo pessoal.
                </p>
                <div className="pt-4 flex flex-col sm:flex-row gap-4 justify-center">
                  <button 
                    onClick={() => {
                      setCurrentView('catalog');
                      setSelectedCategory('Todos');
                    }}
                    className="inline-flex items-center justify-center px-8 py-4 bg-[#FBF9F5] text-[#1A1A1A] text-xs uppercase tracking-widest font-semibold hover:bg-[#C5A059] hover:text-white transition-all duration-300 shadow-lg"
                  >
                    Explorar Coleção
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </button>
                  <a
                    href={`https://wa.me/${storeConfig.whatsappNumber}?text=${encodeURIComponent('Olá, gostaria de agendar um atendimento exclusivo na La Boutique São Paulo.')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center px-8 py-4 bg-transparent border border-white/80 text-white text-xs uppercase tracking-widest font-semibold hover:bg-white/10 transition-all duration-300"
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Atendimento Privado
                  </a>
                </div>
              </div>
            </section>

            {/* BRAND VALUE PROP / CONFIRMED HIGHLIGHTS */}
            <section className="py-12 bg-[#F4F1EA]/60 border-y border-[#E8DFD8]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                  <div className="p-4 space-y-2">
                    <ShieldCheck className="w-8 h-8 mx-auto text-[#C5A059] stroke-[1.2]" />
                    <h3 className="font-serif text-base uppercase tracking-wider">Atendimento Personalizado</h3>
                    <p className="text-xs text-[#1A1A1A]/70 leading-relaxed max-w-xs mx-auto">
                      Atendimento exclusivo online ou com agendamento no nosso ateliê localizado em São Paulo.
                    </p>
                  </div>
                  <div className="p-4 space-y-2">
                    <Truck className="w-8 h-8 mx-auto text-[#C5A059] stroke-[1.2]" />
                    <h3 className="font-serif text-base uppercase tracking-wider">Curadoria Exclusiva</h3>
                    <p className="text-xs text-[#1A1A1A]/70 leading-relaxed max-w-xs mx-auto">
                      Peças selecionadas rigidamente, garantindo tecidos nobres, acabamento primoroso e corte perfeito.
                    </p>
                  </div>
                  <div className="p-4 space-y-2">
                    <RefreshCw className="w-8 h-8 mx-auto text-[#C5A059] stroke-[1.2]" />
                    <h3 className="font-serif text-base uppercase tracking-wider">Segurança & Transparência</h3>
                    <p className="text-xs text-[#1A1A1A]/70 leading-relaxed max-w-xs mx-auto">
                      Negociação direta e suporte via WhatsApp antes de qualquer envio.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* FEATURED CATEGORIES GRID */}
            <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-12 space-y-2">
                <span className="text-xs uppercase tracking-[0.3em] text-[#C5A059]">Categorias</span>
                <h2 className="font-serif text-3xl sm:text-4xl text-[#1A1A1A]">Curadoria de Estilo</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {[
                  { name: "Alfaiataria", img: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=800&auto=format&fit=crop" },
                  { name: "Vestidos", img: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?q=80&w=800&auto=format&fit=crop" },
                  { name: "Tricô", img: "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?q=80&w=800&auto=format&fit=crop" }
                ].map((cat, idx) => (
                  <div 
                    key={idx}
                    onClick={() => {
                      setSelectedCategory(cat.name);
                      setCurrentView('catalog');
                    }}
                    className="group relative h-96 overflow-hidden cursor-pointer bg-gray-100"
                  >
                    <img 
                      src={cat.img} 
                      alt={cat.name} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/25 transition-opacity group-hover:bg-black/40" />
                    <div className="absolute inset-0 flex flex-col items-center justify-end p-8 text-white text-center">
                      <h3 className="font-serif text-2xl tracking-wide mb-2">{cat.name}</h3>
                      <span className="text-xs uppercase tracking-widest border-b border-white/60 pb-1 group-hover:border-white transition-colors">
                        Ver Seleção
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* FEATURED PRODUCTS */}
            <section className="py-16 bg-[#F4F1EA]/40 border-t border-[#E8DFD8]/50">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
                  <div>
                    <span className="text-xs uppercase tracking-[0.3em] text-[#C5A059]">Destaques</span>
                    <h2 className="font-serif text-3xl text-[#1A1A1A]">Peças em Evidência</h2>
                  </div>
                  <button 
                    onClick={() => {
                      setCurrentView('catalog');
                      setSelectedCategory('Todos');
                    }}
                    className="mt-4 md:mt-0 text-xs uppercase tracking-widest font-semibold text-[#1A1A1A] hover:text-[#C5A059] inline-flex items-center"
                  >
                    Ver Todo o Catálogo <ArrowRight className="w-3.5 h-3.5 ml-1" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                  {products.filter(p => p.isFeatured).slice(0, 4).map(product => (
                    <ProductCard 
                      key={product.id}
                      product={product}
                      formatBRL={formatBRL}
                      onSelect={() => setSelectedProduct(product)}
                      onWishlistToggle={() => toggleWishlist(product)}
                      isInWishlist={wishlist.some(w => w.id === product.id)}
                    />
                  ))}
                </div>
              </div>
            </section>

            {/* EDITORIAL BANNER */}
            <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="relative bg-[#1A1A1A] text-white p-8 sm:p-16 overflow-hidden flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="space-y-4 max-w-xl z-10">
                  <span className="text-xs uppercase tracking-[0.3em] text-[#C5A059]">Experiência Presencial</span>
                  <h3 className="font-serif text-3xl sm:text-4xl">Visite Nosso Ateliê em São Paulo</h3>
                  <p className="text-sm text-[#E8DFD8] font-light leading-relaxed">
                    Localizado no coração dos Jardins, oferecemos atendimento privativo com consultoria de estilo e prova sob medida.
                  </p>
                  <div className="pt-2">
                    <button 
                      onClick={() => setCurrentView('contact')}
                      className="px-6 py-3 bg-[#C5A059] text-white text-xs uppercase tracking-widest hover:bg-[#b38f47] transition-colors"
                    >
                      Agendar Visita
                    </button>
                  </div>
                </div>
                <div className="w-full md:w-1/2 h-64 md:h-80 relative z-10">
                  <img 
                    src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=1000&auto=format&fit=crop" 
                    alt="Ateliê La Boutique SP" 
                    className="w-full h-full object-cover filter grayscale contrast-125 border border-white/10"
                  />
                </div>
              </div>
            </section>

            {/* NEWSLETTER SECTION */}
            <section className="py-16 bg-[#E8DFD8]/30 border-t border-[#E8DFD8]">
              <div className="max-w-2xl mx-auto text-center px-4 space-y-4">
                <Mail className="w-6 h-6 mx-auto text-[#C5A059]" />
                <h3 className="font-serif text-2xl text-[#1A1A1A]">Acompanhe as Novidades</h3>
                <p className="text-xs text-[#1A1A1A]/70 leading-relaxed">
                  Inscreva-se para receber convites exclusivos de lançamentos de coleções e cápsulas privadas.
                </p>

                {newsletterSuccess ? (
                  <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded">
                    Obrigado por se inscrever! Em breve você receberá nossos boletins exclusivos.
                  </div>
                ) : (
                  <form onSubmit={handleNewsletterSubmit} className="space-y-3 pt-2">
                    <div className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
                      <input 
                        type="email"
                        required
                        placeholder="Seu e-mail principal"
                        value={newsletterEmail}
                        onChange={(e) => setNewsletterEmail(e.target.value)}
                        className="flex-1 px-4 py-3 bg-white border border-[#E8DFD8] text-xs focus:outline-none focus:border-[#C5A059]"
                      />
                      <button 
                        type="submit"
                        disabled={!newsletterConsented}
                        className="px-6 py-3 bg-[#1A1A1A] text-white text-xs uppercase tracking-widest disabled:opacity-50 hover:bg-[#C5A059] transition-colors"
                      >
                        Inscrever
                      </button>
                    </div>
                    <label className="flex items-center justify-center gap-2 text-[11px] text-[#1A1A1A]/70 cursor-pointer pt-1">
                      <input 
                        type="checkbox"
                        checked={newsletterConsented}
                        onChange={(e) => setNewsletterConsented(e.target.checked)}
                        className="rounded accent-[#C5A059]"
                      />
                      <span>Concordo em receber comunicações da La Boutique SP com consentimento.</span>
                    </label>
                  </form>
                )}
              </div>
            </section>
          </div>
        )}

        {/* ==================== VIEW: CATALOG ==================== */}
        {currentView === 'catalog' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            
            {/* Header / Title */}
            <div className="text-center max-w-xl mx-auto mb-12 space-y-2">
              <span className="text-xs uppercase tracking-[0.3em] text-[#C5A059]">Catálogo Demonstrativo</span>
              <h2 className="font-serif text-3xl sm:text-4xl text-[#1A1A1A]">Coleção La Boutique</h2>
              <p className="text-xs text-[#1A1A1A]/60">
                Abaixo estão listadas peças de demonstração. Os valores e estoque são simulados.
              </p>
            </div>

            {/* Filter & Search Toolbar */}
            <div className="bg-[#F4F1EA]/80 p-6 border border-[#E8DFD8] mb-10 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                
                {/* Search */}
                <div className="relative">
                  <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/60 mb-1">Buscar</label>
                  <input 
                    type="text" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Nome da peça..."
                    className="w-full px-3 py-2 text-xs bg-white border border-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  />
                </div>

                {/* Category Filter */}
                <div>
                  <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/60 mb-1">Categoria</label>
                  <select 
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  >
                    <option value="Todos">Todas as Categorias</option>
                    <option value="Alfaiataria">Alfaiataria</option>
                    <option value="Vestidos">Vestidos</option>
                    <option value="Tricô">Tricô</option>
                    <option value="Camisas">Camisas</option>
                    <option value="Casacos">Casacos</option>
                  </select>
                </div>

                {/* Size Filter */}
                <div>
                  <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/60 mb-1">Tamanho</label>
                  <select 
                    value={selectedSizeFilter}
                    onChange={(e) => setSelectedSizeFilter(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  >
                    <option value="Todos">Todos os Tamanhos</option>
                    <option value="PP">PP</option>
                    <option value="P">P</option>
                    <option value="M">M</option>
                    <option value="G">G</option>
                    <option value="GG">GG</option>
                  </select>
                </div>

                {/* Sort By */}
                <div>
                  <label className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/60 mb-1">Ordenar por</label>
                  <select 
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                  >
                    <option value="newest">Novidades Primeiro</option>
                    <option value="price-asc">Menor Preço</option>
                    <option value="price-desc">Maior Preço</option>
                    <option value="popular">Mais Populares</option>
                  </select>
                </div>

              </div>

              {/* Price Range Slider */}
              <div className="pt-2 border-t border-[#E8DFD8]/60 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="w-full sm:w-1/2">
                  <div className="flex justify-between text-xs text-[#1A1A1A]/70 mb-1">
                    <span>Preço máximo:</span>
                    <span className="font-semibold">{formatBRL(priceRange)}</span>
                  </div>
                  <input 
                    type="range" 
                    min="300" 
                    max="2500" 
                    step="50"
                    value={priceRange}
                    onChange={(e) => setPriceRange(Number(e.target.value))}
                    className="w-full accent-[#C5A059]"
                  />
                </div>

                <div className="text-xs text-[#1A1A1A]/60">
                  Exibindo <strong>{filteredProducts.length}</strong> de <strong>{products.length}</strong> itens
                </div>
              </div>
            </div>

            {/* Products Grid */}
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {filteredProducts.map(product => (
                  <ProductCard 
                    key={product.id}
                    product={product}
                    formatBRL={formatBRL}
                    onSelect={() => setSelectedProduct(product)}
                    onWishlistToggle={() => toggleWishlist(product)}
                    isInWishlist={wishlist.some(w => w.id === product.id)}
                  />
                ))}
              </div>
            ) : (
              <div className="py-20 text-center space-y-4">
                <p className="font-serif text-lg text-gray-500">Nenhuma peça encontrada com os filtros selecionados.</p>
                <button 
                  onClick={() => {
                    setSelectedCategory('Todos');
                    setSelectedSizeFilter('Todos');
                    setPriceRange(2500);
                    setSearchQuery('');
                  }}
                  className="px-6 py-2 bg-[#1A1A1A] text-white text-xs uppercase tracking-widest"
                >
                  Limpar Filtros
                </button>
              </div>
            )}
          </div>
        )}

        {/* ==================== VIEW: ABOUT US ==================== */}
        {currentView === 'about' && (
          <div className="max-w-4xl mx-auto px-4 py-16 space-y-12">
            <div className="text-center space-y-3">
              <span className="text-xs uppercase tracking-[0.3em] text-[#C5A059]">Nossa História</span>
              <h2 className="font-serif text-4xl text-[#1A1A1A]">A Essência La Boutique</h2>
              <div className="w-12 h-[1px] bg-[#C5A059] mx-auto" />
            </div>

            <div className="relative h-80 overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=1200&auto=format&fit=crop" 
                alt="Ateliê La Boutique SP" 
                className="w-full h-full object-cover filter brightness-[0.9]"
              />
            </div>

            <div className="prose prose-stone max-w-none text-sm text-[#1A1A1A]/80 leading-relaxed space-y-6">
              <p>
                Fundada no coração de São Paulo, a <strong>La Boutique</strong> nasceu do desejo de trazer uma perspectiva contemporânea e minimalista para a moda feminina premium. Acreditamos na força da simplicidade aliada a matérias-primas nobres e alfaiataria impecável.
              </p>
              <p>
                Cada peça do nosso portfólio é concebida como um investimento atemporal. Priorizamos acabamentos manuais, caimentos estruturados e paletas neutras que ultrapassam tendências passageiras, oferecendo elegância natural para o dia a dia e momentos memoráveis.
              </p>
              <div className="p-6 bg-[#F4F1EA] border-l-2 border-[#C5A059] italic text-xs space-y-2">
                <p>
                  "A verdadeira elegância reside na autenticidade e no cuidado silencioso com cada costura."
                </p>
                <span className="block font-semibold not-italic text-[#1A1A1A]">— Direção Criativa, La Boutique São Paulo</span>
              </div>
            </div>
          </div>
        )}

        {/* ==================== VIEW: CONTACT ==================== */}
        {currentView === 'contact' && (
          <div className="max-w-5xl mx-auto px-4 py-16">
            <div className="text-center max-w-xl mx-auto mb-12 space-y-2">
              <span className="text-xs uppercase tracking-[0.3em] text-[#C5A059]">Atendimento Personalizado</span>
              <h2 className="font-serif text-4xl text-[#1A1A1A]">Fale Conosco</h2>
              <p className="text-xs text-[#1A1A1A]/70">
                Estamos prontos para atende-la, tirar dúvidas ou agendar uma visita privativa.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              {/* Contact Info & Demo Location */}
              <div className="space-y-8 bg-[#F4F1EA] p-8 border border-[#E8DFD8]">
                <div>
                  <h3 className="font-serif text-xl mb-4">Ateliê & Showroom</h3>
                  <div className="space-y-4 text-xs text-[#1A1A1A]/80">
                    <p className="flex items-start gap-3">
                      <MapPin className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                      <span>Alameda Lorena (Endereço Demonstrativo)<br />Jardins, São Paulo - SP, Brasil</span>
                    </p>
                    <p className="flex items-center gap-3">
                      <Clock className="w-4 h-4 text-[#C5A059] shrink-0" />
                      <span>Segunda a Sexta: 10h às 19h | Sábado: 10h às 16h</span>
                    </p>
                    <p className="flex items-center gap-3">
                      <Phone className="w-4 h-4 text-[#C5A059] shrink-0" />
                      <span>{storeConfig.whatsappFormatted} (Contato Oficial a confirmar)</span>
                    </p>
                    <p className="flex items-center gap-3">
                      <Mail className="w-4 h-4 text-[#C5A059] shrink-0" />
                      <span>contato@laboutiquesp.demo.br</span>
                    </p>
                  </div>
                </div>

                <div className="pt-4 border-t border-[#E8DFD8]">
                  <h4 className="font-serif text-sm mb-2">Atendimento Imediato via WhatsApp</h4>
                  <a 
                    href={`https://wa.me/${storeConfig.whatsappNumber}?text=${encodeURIComponent('Olá, gostaria de falar com uma consultora da La Boutique.')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-[#25D366] text-white text-xs uppercase tracking-widest font-semibold hover:bg-emerald-600 transition-colors w-full justify-center"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Iniciar Conversa no WhatsApp
                  </a>
                </div>
              </div>

              {/* Contact Form */}
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  alert("Mensagem enviada com sucesso no modo de demonstração!");
                }}
                className="space-y-4 bg-white p-8 border border-[#E8DFD8]"
              >
                <h3 className="font-serif text-xl mb-4">Envie uma Mensagem</h3>
                <div>
                  <label className="block text-[10px] uppercase tracking-widest mb-1">Nome Completo</label>
                  <input type="text" required placeholder="Sua identificação" className="w-full px-3 py-2 text-xs border border-[#E8DFD8] focus:outline-none focus:border-[#C5A059]" />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-widest mb-1">E-mail</label>
                  <input type="email" required placeholder="seu@email.com" className="w-full px-3 py-2 text-xs border border-[#E8DFD8] focus:outline-none focus:border-[#C5A059]" />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-widest mb-1">Telefone / WhatsApp</label>
                  <input type="tel" placeholder="(11) 99999-0000" className="w-full px-3 py-2 text-xs border border-[#E8DFD8] focus:outline-none focus:border-[#C5A059]" />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-widest mb-1">Mensagem</label>
                  <textarea rows="4" required placeholder="Como podemos ajudar?" className="w-full px-3 py-2 text-xs border border-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"></textarea>
                </div>
                <button type="submit" className="w-full py-3 bg-[#1A1A1A] text-white text-xs uppercase tracking-widest hover:bg-[#C5A059] transition-colors">
                  Enviar Mensagem
                </button>
              </form>
            </div>
          </div>
        )}

        {/* ==================== VIEW: FAQ & POLICIES ==================== */}
        {currentView === 'faq' && (
          <div className="max-w-4xl mx-auto px-4 py-16 space-y-10">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <span className="text-xs uppercase tracking-[0.3em] text-[#C5A059]">Modelos de Políticas</span>
              <h2 className="font-serif text-4xl text-[#1A1A1A]">Perguntas & Políticas</h2>
              <p className="text-xs text-[#1A1A1A]/60">
                Os textos abaixo servem como modelo editável para aprovação final da proprietária.
              </p>
            </div>

            <div className="space-y-6">
              {[
                {
                  title: "1. Trocas e Devoluções (Modelo Padrão CDC)",
                  content: "Respeitamos o Direito de Arrependimento constante no Código de Defesa do Consumidor. A solicitação de troca ou devolução por compras online pode ser efetuada em até 7 (sete) dias corridos após o recebimento do pedido, desde que a peça esteja sem indícios de uso, com etiqueta fixada e embalagem original."
                },
                {
                  title: "2. Envios e Prazos para São Paulo e Brasil",
                  content: "Os prazos e opções de entrega (expressa via motoboy para Grande São Paulo ou Correios/Transportadora para demais estados) serão combinados e confirmados previamente pelo atendimento via WhatsApp antes de qualquer faturamento."
                },
                {
                  title: "3. Formas de Pagamento Aceitas",
                  content: "Aceitamos principais cartões de crédito (com possibilidade de parcelamento a ser definido pela loja), PIX com desconto à vista sob consulta e transferência bancária direta."
                },
                {
                  title: "4. Privacidade e Consentimento de Dados",
                  content: "Os dados pessoais coletados neste site (como e-mail e telefone) são de uso exclusivo da La Boutique São Paulo para fins de atendimento ao cliente e newsletters autorizadas, em estrita conformidade com a LGPD."
                }
              ].map((item, idx) => (
                <div key={idx} className="bg-white p-6 border border-[#E8DFD8] space-y-2">
                  <h3 className="font-serif text-base text-[#1A1A1A] flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-[#C5A059]" />
                    {item.title}
                  </h3>
                  <p className="text-xs text-[#1A1A1A]/70 leading-relaxed pl-6">
                    {item.content}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==================== VIEW: ADMIN DASHBOARD ==================== */}
        {currentView === 'admin' && (
          <div className="max-w-6xl mx-auto px-4 py-16">
            {!isAdminAuthenticated ? (
              <div className="max-w-md mx-auto bg-white p-8 border border-[#E8DFD8] shadow-sm space-y-6">
                <div className="text-center space-y-2">
                  <Lock className="w-8 h-8 mx-auto text-[#C5A059]" />
                  <h2 className="font-serif text-2xl">Painel de Gestão La Boutique</h2>
                  <p className="text-xs text-gray-500">
                    Acesso restrito para a proprietária da loja.
                  </p>
                </div>

                {adminError && (
                  <div className="p-3 bg-red-50 text-red-700 text-xs border border-red-200">
                    {adminError}
                  </div>
                )}

                <form onSubmit={handleAdminAuth} className="space-y-4">
                  <div>
                    <label className="block text-[10px] uppercase tracking-widest mb-1">PIN / Senha de Acesso Demo</label>
                    <input 
                      type="password" 
                      placeholder="Digite 1234" 
                      value={adminPinInput}
                      onChange={(e) => setAdminPinInput(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-[#E8DFD8] focus:outline-none focus:border-[#C5A059]"
                    />
                    <p className="text-[10px] text-gray-400 mt-1">Dica de demonstração: Utilize a senha <strong>1234</strong></p>
                  </div>
                  <button type="submit" className="w-full py-3 bg-[#1A1A1A] text-white text-xs uppercase tracking-widest hover:bg-[#C5A059] transition-colors">
                    Entrar no Painel
                  </button>
                </form>
              </div>
            ) : (
              <div className="space-y-10">
                {/* Admin Header */}
                <div className="flex flex-col sm:flex-row items-center justify-between pb-6 border-b border-[#E8DFD8] gap-4">
                  <div>
                    <span className="text-xs uppercase tracking-widest text-[#C5A059]">Administração da Loja</span>
                    <h2 className="font-serif text-3xl">Gerenciamento La Boutique SP</h2>
                  </div>
                  <button 
                    onClick={() => setIsAdminAuthenticated(false)}
                    className="px-4 py-2 border border-gray-300 text-xs uppercase tracking-widest hover:bg-gray-100"
                  >
                    Sair do Painel
                  </button>
                </div>

                {/* Config Quick Edit */}
                <div className="bg-[#F4F1EA] p-6 border border-[#E8DFD8] space-y-4">
                  <h3 className="font-serif text-lg flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#C5A059]" />
                    Configurações do Topo e WhatsApp
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block mb-1 font-semibold">Aviso Superior (Topo):</label>
                      <input 
                        type="text" 
                        value={storeConfig.announcementText}
                        onChange={(e) => setStoreConfig({ ...storeConfig, announcementText: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-[#E8DFD8]"
                      />
                    </div>
                    <div>
                      <label className="block mb-1 font-semibold">Número do WhatsApp Comercial (apenas números):</label>
                      <input 
                        type="text" 
                        value={storeConfig.whatsappNumber}
                        onChange={(e) => setStoreConfig({ ...storeConfig, whatsappNumber: e.target.value, whatsappFormatted: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-[#E8DFD8]"
                      />
                    </div>
                  </div>
                </div>

                {/* Products Table Management */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-serif text-xl">Cadastro & Estoque de Produtos ({products.length})</h3>
                    <button 
                      onClick={() => {
                        const newProd = {
                          id: `lb-${Date.now()}`,
                          name: "Nova Peça La Boutique",
                          category: "Alfaiataria",
                          price: 500.00,
                          images: ["https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=1000&auto=format&fit=crop"],
                          sizes: ["P", "M"],
                          colors: [{ name: "Preto", hex: "#1A1A1A" }],
                          isNew: true,
                          isFeatured: false,
                          stock: 5,
                          description: "Descrição da nova peça.",
                          composition: "100% Algodão Premium",
                          care: "Lavar delicadamente"
                        };
                        setProducts([newProd, ...products]);
                      }}
                      className="inline-flex items-center gap-1 px-4 py-2 bg-[#1A1A1A] text-white text-xs uppercase tracking-widest hover:bg-[#C5A059]"
                    >
                      <Plus className="w-3.5 h-3.5" /> Adicionar Peça Demo
                    </button>
                  </div>

                  <div className="overflow-x-auto bg-white border border-[#E8DFD8]">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#F4F1EA] uppercase text-[10px] tracking-wider border-b border-[#E8DFD8]">
                        <tr>
                          <th className="p-3">Imagem</th>
                          <th className="p-3">Nome da Peça</th>
                          <th className="p-3">Categoria</th>
                          <th className="p-3">Preço (R$)</th>
                          <th className="p-3">Estoque</th>
                          <th className="p-3 text-right">Ações</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#E8DFD8]">
                        {products.map(p => (
                          <tr key={p.id} className="hover:bg-gray-50">
                            <td className="p-3">
                              <img src={p.images[0]} alt="" className="w-10 h-12 object-cover" />
                            </td>
                            <td className="p-3 font-semibold">{p.name}</td>
                            <td className="p-3">{p.category}</td>
                            <td className="p-3">{formatBRL(p.price)}</td>
                            <td className="p-3">{p.stock} un</td>
                            <td className="p-3 text-right space-x-2">
                              <button 
                                onClick={() => setEditingProduct(p)}
                                className="p-1 text-gray-600 hover:text-[#C5A059]" 
                                title="Editar"
                              >
                                <Edit className="w-4 h-4 inline" />
                              </button>
                              <button 
                                onClick={() => setProducts(products.filter(item => item.id !== p.id))}
                                className="p-1 text-gray-600 hover:text-red-600" 
                                title="Excluir"
                              >
                                <Trash2 className="w-4 h-4 inline" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Edit Product Modal */}
                {editingProduct && (
                  <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
                    <div className="bg-white max-w-lg w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
                      <div className="flex justify-between items-center border-b pb-2">
                        <h4 className="font-serif text-lg">Editar Peça: {editingProduct.name}</h4>
                        <button onClick={() => setEditingProduct(null)}><X className="w-5 h-5" /></button>
                      </div>

                      <div className="space-y-3 text-xs">
                        <div>
                          <label className="block mb-1">Nome do Produto</label>
                          <input 
                            type="text" 
                            value={editingProduct.name}
                            onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                            className="w-full p-2 border"
                          />
                        </div>

                        <div>
                          <label className="block mb-1">Preço (R$)</label>
                          <input 
                            type="number" 
                            value={editingProduct.price}
                            onChange={(e) => setEditingProduct({ ...editingProduct, price: parseFloat(e.target.value) || 0 })}
                            className="w-full p-2 border"
                          />
                        </div>

                        <div>
                          <label className="block mb-1">Estoque</label>
                          <input 
                            type="number" 
                            value={editingProduct.stock}
                            onChange={(e) => setEditingProduct({ ...editingProduct, stock: parseInt(e.target.value) || 0 })}
                            className="w-full p-2 border"
                          />
                        </div>

                        <div>
                          <label className="block mb-1">URL Imagem</label>
                          <input 
                            type="text" 
                            value={editingProduct.images[0]}
                            onChange={(e) => setEditingProduct({ ...editingProduct, images: [e.target.value] })}
                            className="w-full p-2 border"
                          />
                        </div>

                        <div>
                          <label className="block mb-1">Descrição</label>
                          <textarea 
                            rows="3" 
                            value={editingProduct.description}
                            onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                            className="w-full p-2 border"
                          />
                        </div>
                      </div>

                      <div className="pt-4 flex justify-end gap-2">
                        <button 
                          onClick={() => setEditingProduct(null)}
                          className="px-4 py-2 border text-xs uppercase"
                        >
                          Cancelar
                        </button>
                        <button 
                          onClick={() => {
                            setProducts(products.map(item => item.id === editingProduct.id ? editingProduct : item));
                            setEditingProduct(null);
                          }}
                          className="px-4 py-2 bg-[#1A1A1A] text-white text-xs uppercase"
                        >
                          Salvar Alterações
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

      </main>

      {/* 4. SINGLE PRODUCT DETAIL MODAL */}
      {selectedProduct && (
        <ProductDetailModal 
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          formatBRL={formatBRL}
          addToCart={addToCart}
          generateWhatsAppProductLink={generateWhatsAppProductLink}
        />
      )}

      {/* 5. SHOPPING CART SLIDE-OVER */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity" onClick={() => setIsCartOpen(false)} />

          <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
            <div className="pointer-events-auto w-screen max-w-md bg-[#FBF9F5] shadow-2xl flex flex-col">
              
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-[#E8DFD8]">
                <h2 className="font-serif text-xl tracking-wider uppercase text-[#1A1A1A] flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-[#C5A059]" /> Sacola de Compras
                </h2>
                <button onClick={() => setIsCartOpen(false)} className="p-2 text-gray-400 hover:text-black">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Body */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {cart.length === 0 ? (
                  <div className="text-center py-20 space-y-4">
                    <ShoppingBag className="w-12 h-12 mx-auto text-[#E8DFD8]" />
                    <p className="font-serif text-gray-500">Sua sacola está vazia no momento.</p>
                    <button 
                      onClick={() => {
                        setIsCartOpen(false);
                        setCurrentView('catalog');
                      }}
                      className="px-6 py-2 bg-[#1A1A1A] text-white text-xs uppercase tracking-widest"
                    >
                      Explorar Produtos
                    </button>
                  </div>
                ) : (
                  <>
                    {checkoutStep === 'cart' && (
                      <div className="space-y-4">
                        {cart.map(item => (
                          <div key={item.cartItemId} className="flex gap-4 p-3 bg-white border border-[#E8DFD8] relative">
                            <img src={item.product.images[0]} alt="" className="w-16 h-20 object-cover" />
                            <div className="flex-1 space-y-1 text-xs">
                              <h4 className="font-serif font-semibold pr-6">{item.product.name}</h4>
                              <p className="text-gray-500">Tam: {item.size} | Cor: {item.color.name}</p>
                              <p className="font-semibold text-[#C5A059]">{formatBRL(item.unitPrice)}</p>
                              
                              <div className="flex items-center gap-2 pt-2">
                                <button onClick={() => updateCartQty(item.cartItemId, -1)} className="p-1 border text-gray-600">
                                  <Minus className="w-3 h-3" />
                                </button>
                                <span className="px-2">{item.quantity}</span>
                                <button onClick={() => updateCartQty(item.cartItemId, 1)} className="p-1 border text-gray-600">
                                  <Plus className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                            <button 
                              onClick={() => removeFromCart(item.cartItemId)}
                              className="absolute top-2 right-2 text-gray-400 hover:text-red-600 p-1"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    {checkoutStep === 'address' && (
                      <div className="space-y-4 text-xs">
                        <h3 className="font-serif text-base border-b pb-2">Dados para Atendimento / Entrega</h3>
                        <div>
                          <label className="block mb-1 uppercase tracking-widest text-[10px]">Nome Completo</label>
                          <input 
                            type="text" 
                            required
                            value={customerData.name}
                            onChange={(e) => setCustomerData({ ...customerData, name: e.target.value })}
                            className="w-full px-3 py-2 border bg-white" 
                            placeholder="Sua identificação"
                          />
                        </div>
                        <div>
                          <label className="block mb-1 uppercase tracking-widest text-[10px]">Telefone / WhatsApp</label>
                          <input 
                            type="tel" 
                            required
                            value={customerData.phone}
                            onChange={(e) => setCustomerData({ ...customerData, phone: e.target.value })}
                            className="w-full px-3 py-2 border bg-white" 
                            placeholder="(11) 99999-0000"
                          />
                        </div>
                        <div>
                          <label className="block mb-1 uppercase tracking-widest text-[10px]">Endereço em SP / Brasil</label>
                          <input 
                            type="text" 
                            value={customerData.address}
                            onChange={(e) => setCustomerData({ ...customerData, address: e.target.value })}
                            className="w-full px-3 py-2 border bg-white" 
                            placeholder="Rua, número, complemento e bairro"
                          />
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>

              {/* Footer Calculations */}
              {cart.length > 0 && (
                <div className="p-6 border-t border-[#E8DFD8] bg-[#F4F1EA]/60 space-y-4">
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between text-gray-600">
                      <span>Subtotal:</span>
                      <span>{formatBRL(cartSubtotal)}</span>
                    </div>
                    <div className="flex justify-between text-gray-600">
                      <span>Frete / Atendimento SP:</span>
                      <span className="italic">A combinar via WhatsApp</span>
                    </div>
                    <div className="flex justify-between text-sm font-semibold text-[#1A1A1A] pt-2 border-t">
                      <span>Total Previsto:</span>
                      <span className="text-[#C5A059]">{formatBRL(cartSubtotal)}</span>
                    </div>
                  </div>

                  {checkoutStep === 'cart' ? (
                    <button 
                      onClick={() => setCheckoutStep('address')}
                      className="w-full py-3 bg-[#1A1A1A] text-white text-xs uppercase tracking-widest hover:bg-[#C5A059] transition-colors"
                    >
                      Avançar para Atendimento
                    </button>
                  ) : (
                    <div className="space-y-2">
                      <a 
                        href={generateWhatsAppCartLink()}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center justify-center gap-2 w-full py-3 bg-[#25D366] text-white text-xs uppercase tracking-widest font-semibold hover:bg-emerald-600 transition-colors"
                      >
                        <MessageCircle className="w-4 h-4" />
                        Finalizar Pedido via WhatsApp
                      </a>
                      <button 
                        onClick={() => setCheckoutStep('cart')}
                        className="w-full py-2 text-xs text-gray-500 underline text-center"
                      >
                        Voltar para a Sacola
                      </button>
                    </div>
                  )}

                  <p className="text-[10px] text-gray-400 text-center">
                    🔒 Nenhuma cobrança é realizada neste site. Todo o checkout é finalizado com suporte presencial/humano.
                  </p>
                </div>
              )}

            </div>
          </div>
        </div>
      )}

      {/* 6. WISHLIST DRAWER */}
      {isWishlistOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setIsWishlistOpen(false)} />
          <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
            <div className="pointer-events-auto w-screen max-w-md bg-[#FBF9F5] shadow-2xl flex flex-col p-6">
              <div className="flex justify-between items-center border-b pb-4 mb-4">
                <h3 className="font-serif text-lg flex items-center gap-2">
                  <Heart className="w-5 h-5 text-[#C5A059]" /> Meus Favoritos ({wishlist.length})
                </h3>
                <button onClick={() => setIsWishlistOpen(false)}><X className="w-5 h-5" /></button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-4">
                {wishlist.length === 0 ? (
                  <p className="text-center text-xs text-gray-500 py-12">Nenhuma peça favoritada até o momento.</p>
                ) : (
                  wishlist.map(product => (
                    <div key={product.id} className="flex gap-4 p-3 bg-white border border-[#E8DFD8] items-center">
                      <img src={product.images[0]} alt="" className="w-14 h-16 object-cover" />
                      <div className="flex-1 text-xs space-y-1">
                        <h4 className="font-semibold">{product.name}</h4>
                        <p className="text-[#C5A059] font-semibold">{formatBRL(product.price)}</p>
                      </div>
                      <button 
                        onClick={() => {
                          setSelectedProduct(product);
                          setIsWishlistOpen(false);
                        }}
                        className="p-2 text-xs bg-[#1A1A1A] text-white uppercase"
                      >
                        Ver
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 7. QUICK SEARCH OVERLAY */}
      {isSearchOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-start justify-center pt-20 px-4">
          <div className="bg-[#FBF9F5] w-full max-w-2xl p-6 border border-[#E8DFD8] space-y-4 relative">
            <button onClick={() => setIsSearchOpen(false)} className="absolute top-4 right-4 text-gray-500">
              <X className="w-6 h-6" />
            </button>
            <h3 className="font-serif text-xl text-[#1A1A1A]">O que você procura?</h3>
            <div className="relative">
              <input 
                type="text"
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Busque por alfaiataria, vestidos, tricô..."
                className="w-full py-3 pl-4 pr-10 bg-white border border-[#E8DFD8] text-sm focus:outline-none focus:border-[#C5A059]"
              />
              <Search className="w-5 h-5 absolute right-3 top-3 text-gray-400" />
            </div>
            
            <div className="pt-2 text-center">
              <button 
                onClick={() => {
                  setIsSearchOpen(false);
                  setCurrentView('catalog');
                }}
                className="px-6 py-2 bg-[#1A1A1A] text-white text-xs uppercase tracking-widest"
              >
                Ver Resultados Completo no Catálogo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. FOOTER */}
      <footer className="bg-[#1A1A1A] text-white border-t border-[#C5A059]/20 pt-16 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-xs font-light tracking-wide">
            
            {/* Brand Intro */}
            <div className="space-y-4">
              <h2 className="font-serif text-2xl tracking-widest uppercase text-white">La Boutique</h2>
              <p className="text-[#E8DFD8]/70 leading-relaxed">
                Boutique de moda feminina premium localizada em São Paulo. Elegância, minimalismo e caimento impecável.
              </p>
              <div className="flex space-x-4 pt-2 text-[#C5A059]">
                <Instagram className="w-4 h-4 cursor-pointer hover:text-white" />
                <Facebook className="w-4 h-4 cursor-pointer hover:text-white" />
              </div>
            </div>

            {/* Quick Links */}
            <div className="space-y-3">
              <h4 className="font-serif text-sm uppercase text-[#C5A059] tracking-widest">Navegação</h4>
              <ul className="space-y-2 text-[#E8DFD8]/80">
                <li><button onClick={() => setCurrentView('catalog')} className="hover:text-white">Coleção Completa</button></li>
                <li><button onClick={() => setCurrentView('about')} className="hover:text-white">Sobre a Marca</button></li>
                <li><button onClick={() => setCurrentView('contact')} className="hover:text-white">Ateliê São Paulo</button></li>
                <li><button onClick={() => setCurrentView('admin')} className="hover:text-white">Acesso Proprietário</button></li>
              </ul>
            </div>

            {/* Legal Policies */}
            <div className="space-y-3">
              <h4 className="font-serif text-sm uppercase text-[#C5A059] tracking-widest">Atendimento</h4>
              <ul className="space-y-2 text-[#E8DFD8]/80">
                <li><button onClick={() => setCurrentView('faq')} className="hover:text-white">Trocas e Devoluções</button></li>
                <li><button onClick={() => setCurrentView('faq')} className="hover:text-white">Prazos e Entregas</button></li>
                <li><button onClick={() => setCurrentView('faq')} className="hover:text-white">Política de Privacidade</button></li>
              </ul>
            </div>

            {/* Contact Details */}
            <div className="space-y-3">
              <h4 className="font-serif text-sm uppercase text-[#C5A059] tracking-widest">São Paulo - SP</h4>
              <p className="text-[#E8DFD8]/70">Alameda Lorena, Jardins</p>
              <p className="text-[#E8DFD8]/70">WhatsApp: {storeConfig.whatsappFormatted}</p>
              <p className="text-[10px] text-gray-500 pt-2">
                *Dados demonstrativos prontos para substituição pela proprietária.
              </p>
            </div>

          </div>

          <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#E8DFD8]/50 gap-4">
            <p>© {new Date().getFullYear()} La Boutique São Paulo. Todos os direitos reservados.</p>
            <p>Demonstração comercial exclusiva de alta sofisticação.</p>
          </div>
        </div>
      </footer>

    </div>
  );
}

// --- HELPER COMPONENT: PRODUCT CARD ---
function ProductCard({ product, formatBRL, onSelect, onWishlistToggle, isInWishlist }) {
  const [currentImgIndex, setCurrentImgIndex] = useState(0);

  return (
    <div className="group relative flex flex-col bg-white border border-[#E8DFD8]/60 overflow-hidden transition-all duration-300 hover:shadow-md">
      
      {/* Image Container with Hover Swap */}
      <div 
        className="relative aspect-[3/4] bg-gray-100 overflow-hidden cursor-pointer"
        onClick={onSelect}
        onMouseEnter={() => product.images[1] && setCurrentImgIndex(1)}
        onMouseLeave={() => setCurrentImgIndex(0)}
      >
        <img 
          src={product.images[currentImgIndex]} 
          alt={product.name} 
          className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
        />

        {/* Demo Badge */}
        <span className="absolute top-2 left-2 bg-[#1A1A1A]/80 text-[#E8DFD8] text-[9px] uppercase tracking-wider px-2 py-0.5 font-mono">
          [Demonstração]
        </span>

        {/* New Tag */}
        {product.isNew && (
          <span className="absolute top-2 right-2 bg-[#C5A059] text-white text-[9px] uppercase tracking-widest px-2 py-0.5">
            Novo
          </span>
        )}

        {/* Quick Wishlist Toggle */}
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onWishlistToggle();
          }}
          className="absolute bottom-3 right-3 p-2 rounded-full bg-white/80 backdrop-blur-sm text-[#1A1A1A] hover:text-[#C5A059] transition-colors shadow"
          title="Salvar nos Favoritos"
        >
          <Heart className={`w-4 h-4 ${isInWishlist ? 'fill-[#C5A059] text-[#C5A059]' : ''}`} />
        </button>
      </div>

      {/* Details */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-2">
        <div>
          <span className="text-[10px] uppercase tracking-widest text-[#C5A059] font-medium">
            {product.category}
          </span>
          <h3 
            onClick={onSelect}
            className="font-serif text-sm text-[#1A1A1A] hover:text-[#C5A059] cursor-pointer transition-colors line-clamp-1"
          >
            {product.name}
          </h3>
        </div>

        {/* Price & Swatches */}
        <div className="pt-2 border-t border-[#E8DFD8]/40 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[#1A1A1A]">
              {formatBRL(product.price)}
            </span>
            {product.oldPrice && (
              <span className="text-[10px] text-gray-400 line-through">
                {formatBRL(product.oldPrice)}
              </span>
            )}
          </div>

          {/* Color Dots */}
          <div className="flex -space-x-1">
            {product.colors.map((c, idx) => (
              <span 
                key={idx}
                className="w-2.5 h-2.5 rounded-full border border-gray-300"
                style={{ backgroundColor: c.hex }}
                title={c.name}
              />
            ))}
          </div>
        </div>
      </div>

    </div>
  );
}

// --- HELPER COMPONENT: PRODUCT DETAIL MODAL ---
function ProductDetailModal({ product, onClose, formatBRL, addToCart, generateWhatsAppProductLink }) {
  const [selectedSize, setSelectedSize] = useState(product.sizes[0] || 'P');
  const [selectedColor, setSelectedColor] = useState(product.colors[0] || { name: 'Padrão', hex: '#000' });
  const [activeImage, setActiveImage] = useState(product.images[0]);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#FBF9F5] max-w-4xl w-full border border-[#E8DFD8] relative my-8 shadow-2xl overflow-hidden">
        
        {/* Close button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-gray-500 hover:text-black bg-white/80 rounded-full"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          
          {/* Gallery */}
          <div className="p-6 space-y-4 bg-white">
            <div className="aspect-[3/4] bg-gray-100 overflow-hidden">
              <img src={activeImage} alt="" className="w-full h-full object-cover" />
            </div>
            {product.images.length > 1 && (
              <div className="flex gap-2">
                {product.images.map((img, idx) => (
                  <img 
                    key={idx}
                    src={img}
                    alt=""
                    onClick={() => setActiveImage(img)}
                    className={`w-16 h-20 object-cover cursor-pointer border-2 ${activeImage === img ? 'border-[#C5A059]' : 'border-transparent'}`}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div className="p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <span className="text-xs uppercase tracking-[0.3em] text-[#C5A059]">
                {product.category} • Ref: {product.id}
              </span>
              <h2 className="font-serif text-2xl text-[#1A1A1A]">{product.name}</h2>
              
              <div className="flex items-center gap-3">
                <span className="text-xl font-serif text-[#1A1A1A]">{formatBRL(product.price)}</span>
                <span className="text-[10px] text-gray-500 uppercase tracking-widest border px-2 py-0.5">
                  Estoque: {product.stock} un
                </span>
              </div>

              <p className="text-xs text-[#1A1A1A]/70 leading-relaxed">
                {product.description}
              </p>

              {/* Color Selection */}
              <div className="space-y-2">
                <label className="block text-[10px] uppercase tracking-widest text-gray-500">
                  Cor Selecionada: <strong>{selectedColor.name}</strong>
                </label>
                <div className="flex gap-2">
                  {product.colors.map((c, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedColor(c)}
                      className={`w-7 h-7 rounded-full border-2 transition-all ${
                        selectedColor.name === c.name ? 'border-[#C5A059] scale-110' : 'border-gray-200'
                      }`}
                      style={{ backgroundColor: c.hex }}
                    />
                  ))}
                </div>
              </div>

              {/* Size Selection */}
              <div className="space-y-2">
                <label className="block text-[10px] uppercase tracking-widest text-gray-500">
                  Tamanho
                </label>
                <div className="flex gap-2">
                  {product.sizes.map(s => (
                    <button
                      key={s}
                      onClick={() => setSelectedSize(s)}
                      className={`px-3 py-1.5 text-xs border uppercase transition-colors ${
                        selectedSize === s 
                          ? 'border-[#1A1A1A] bg-[#1A1A1A] text-white' 
                          : 'border-gray-300 text-gray-700 hover:border-black'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Specs */}
              <div className="text-[11px] text-gray-500 space-y-1 pt-2 border-t">
                <p><strong>Composição:</strong> {product.composition}</p>
                <p><strong>Cuidados:</strong> {product.care}</p>
              </div>
            </div>

            {/* CTAs */}
            <div className="space-y-3 pt-4 border-t">
              <button 
                onClick={() => {
                  addToCart(product, selectedSize, selectedColor);
                  onClose();
                }}
                className="w-full py-3 bg-[#1A1A1A] text-white text-xs uppercase tracking-widest hover:bg-[#C5A059] transition-colors"
              >
                Adicionar à Sacola
              </button>

              <a 
                href={generateWhatsAppProductLink(product, selectedSize, selectedColor)}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 w-full py-3 bg-[#25D366] text-white text-xs uppercase tracking-widest font-semibold hover:bg-emerald-600 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                Comprar pelo WhatsApp
              </a>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}