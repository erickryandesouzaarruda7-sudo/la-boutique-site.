# La Boutique — site React

## Publicar grátis com Vercel
1. Descompacte esta pasta.
2. Crie uma conta gratuita em https://github.com e crie um repositório novo chamado `la-boutique-site`.
3. Envie os arquivos desta pasta para o repositório (a pasta `src` e os arquivos `package.json`, `index.html`).
4. Acesse https://vercel.com, entre com GitHub e escolha **Add New → Project**.
5. Importe `la-boutique-site`. A Vercel detecta Vite automaticamente. Use `npm run build` como Build Command e `dist` como Output Directory, se pedir.
6. Clique em **Deploy**. A Vercel dará um endereço público `*.vercel.app`.

## Antes de entregar à loja
- Troque o WhatsApp fictício `5511999998888` pelo número real da loja em `src/App.jsx`.
- Confirme preços, produtos, imagens, endereço e redes sociais com a loja.
- O código contém funcionalidades de demonstração; não trate pagamentos nem pedidos como produção sem integrar e testar um serviço real.
- Não divulgue o PIN de demonstração do painel administrativo; implemente autenticação segura antes de uso real.

## Desenvolvimento local
`npm install` e depois `npm run dev`.
